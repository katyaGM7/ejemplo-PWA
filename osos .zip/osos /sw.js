const CACHE_NAME = 'site-cache-v1';
const DYNAMIC_CACHE = 'dynamic-cache-v1';
const STATIC_FILES = [
  '/',
  '/index.html',
  '/catalogo.html',
  '/contact.html',
  '/about.html',
  '/images/sudadera.jpeg',
  '/images/playera2.jpeg',
  '/images/playera.jpeg',
  '/images/not-found.jpg',
  '/offline.html',
];

// Instalación
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Archivos en caché durante la instalación');
      return cache.addAll(STATIC_FILES);
    })
  );
});

// Activación
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME && cache !== DYNAMIC_CACHE) {
            console.log('Caché antiguo eliminado:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

// Fetch
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      if (response) {
        console.log('Recurso encontrado en caché:', event.request.url);
        return response;
      }

      return fetch(event.request)
        .then((response) => {
          return caches.open(DYNAMIC_CACHE).then((cache) => {
            // Guardar en caché dinámico y limitarlo a 5 archivos
            cache.put(event.request, response.clone());
            cache.keys().then((keys) => {
              if (keys.length > 5) {
                cache.delete(keys[0]);
              }
            });
            return response;
          });
        })
        .catch(() => {
          if (event.request.mode === 'navigate') {
            return caches.match('./offline.html');
            }
            // Si no se encuentra la imagen solicitada, devolver una imagen de "no encontrado"
            if (event.request.url.includes('.jpg')) {
            return caches.match('/images/not-found.jpg');
          }
        });
    })
  );
});


